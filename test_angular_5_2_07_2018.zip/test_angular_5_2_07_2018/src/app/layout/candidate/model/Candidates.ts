import { Candidate } from "./Candidate";
import { CandidateBasic } from "./CandidateBasic";
export interface Candidates {
    listOfCandidates: CandidateBasic[];
}