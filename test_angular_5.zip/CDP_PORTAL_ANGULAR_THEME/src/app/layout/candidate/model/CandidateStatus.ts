export interface CandidateStatus {
    id: string;
    currentStatus: string;
}