export interface CandidateIntervieModel {
    candidateId: string;
    firstPanelistEmailId: string;
    secondPanelistEmailId: string;
    time: string;
    location:string;
    mode:string;   
    interviewId:string; 
}