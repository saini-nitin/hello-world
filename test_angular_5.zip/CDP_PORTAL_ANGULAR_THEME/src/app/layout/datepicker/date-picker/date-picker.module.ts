import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatePickerComponent } from '../../bs-component/components/index';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DatePickerComponent],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class DatePickerModule { }
