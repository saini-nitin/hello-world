package com.cis.constants.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cis.constants.entity.CandidateStatusEntity;
import com.cis.constants.entity.LocationEntity;
import com.cis.constants.model.LocationModel;
import com.cis.constants.service.CandidateService;
import com.cis.constants.service.LocationService;

@CrossOrigin(origins = "*")
@RestController
@EnableAutoConfiguration
@RequestMapping("/cis/constants")
public class ConstantsController {

	@Autowired
	LocationService locationService;
	
	@Autowired
	CandidateService candidateService;
	
	@RequestMapping(value ="/create-location",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public LocationEntity createLocation(@RequestBody LocationModel locationModel) {
		return locationService.createLocation(locationModel);
	}
	
	@RequestMapping(value ="/search-location/{location}",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public LocationModel searchLocation(@PathVariable("location") String locationName ) {
		return locationService.findLocationByName(locationName);
	}
	
	@RequestMapping(value ="/location/{id}",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public Optional<LocationEntity> getLocationById(@PathVariable("id") Long locationId ) {
		return locationService.getLocationById(locationId);
	}
	
	@RequestMapping(value ="/candidateCurrentStatus",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public List<CandidateStatusEntity> getAllCandiadteStatus() {
		return candidateService.getAllCandidateStatus();
	}
	
}
