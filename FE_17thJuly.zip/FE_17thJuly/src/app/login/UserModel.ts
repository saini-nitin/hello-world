export class UserModel {   
    userName:string;
    password:string;
    loginStatus:boolean;
}