export interface CandidateBasic {
    candidateId: string;
    candidateName: string;
    candidateEmail: string;
    candidateContact: string;
    responseStatus:string;
    notes:string;
}