export class CandidateView {
    candidateId: number;
    candidateName: string;
    candidateEmail:string;
    candidateContact:string;
    recievedDate:any;
    currentStatus:string;
    notes:string;
}
  