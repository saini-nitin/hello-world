package com.cis.candidate.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.cis.candidate.entity.CandidateEntity;
import com.cis.candidate.entity.InterviewEntity;
import com.cis.candidate.exception.CandidateNotFoundException;
import com.cis.candidate.exception.DuplicateKeyCustomException;
import com.cis.candidate.exception.FormValidationException;
import com.cis.candidate.mapper.Mapper;
import com.cis.candidate.messages.Messages;
import com.cis.candidate.model.CandidateModel;
import com.cis.candidate.model.CandidateBasicModel;
import com.cis.candidate.model.CandidateInterviewModel;
import com.cis.candidate.repository.CandidateRepository;


@Service
public class CandidateService {
	
	@Autowired
	CandidateRepository candidateRepository;
	
	@Autowired
    Messages messages;
	
	private JavaMailSender javaMailSender;
	
	@Autowired
	public CandidateService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	private static final Logger LOG = LoggerFactory.getLogger(CandidateService.class);
	
	private String createErrorString(Errors errors) {
        return errors.getAllErrors().stream().map(ObjectError::toString).collect(Collectors.joining(","));
    }
	
	public CandidateModel createCandidate(CandidateModel candidateModel, Errors errors) {
		try {
//			if (bindingResult.hasErrors()) {
//				throw new FormValidationException(
//		                new MethodParameter(this.getClass().getDeclaredMethod("createCandidate", CandidateModel.class), 0),
//		                bindingResult);
			
//		    }
//			if (errors.hasErrors()) {
//				throw new FormValidationException(createErrorString(errors));
//	            //return new ResponseEntity<>(createErrorString(errors), HttpStatus.BAD_REQUEST);
//	        }
		Mapper mapper = new Mapper();		
		CandidateEntity candidateEntity = new CandidateEntity();
		candidateEntity = mapper.mapModelToEntity(candidateModel, candidateEntity);
		CandidateEntity candidateOutput = new CandidateEntity();
		candidateOutput = candidateRepository.insert(candidateEntity);
		CandidateModel candidateModelOutput = new CandidateModel();
		if(candidateOutput!=null) {
			candidateModelOutput = mapper.mapEntityToModel(candidateOutput, candidateModelOutput);
			if(candidateModelOutput!=null && candidateModelOutput.getCandidateId()!=null) {
				return candidateModelOutput;
			}else {
				//candidateModelOutput.setResponseStatus("Create Candidate Operation failed. Please try after sometime");
				throw new CandidateNotFoundException(messages.get("TECHNICAL_ERROR"));
			}
		}
		return candidateModelOutput;
		}catch(org.springframework.dao.DuplicateKeyException duplicateKeyException){
			LOG.info("DUPLICATE KEY EXCEPTION OCCURED");
			throw new DuplicateKeyCustomException(messages.get("DUPLICATE_KEY_EXCEPTION"));
		}
	}
	
	public CandidateModel getCandidateDetails(String candidateId) {
		Mapper mapper = new Mapper();
		CandidateModel candidateModel = new CandidateModel();
		Optional<CandidateEntity> optionalEntity =  candidateRepository.findById(candidateId);
		if(optionalEntity.isPresent()) {
			candidateModel = mapper.mapEntityToModel(optionalEntity.get(), candidateModel);
		}else {
			throw new CandidateNotFoundException(messages.get("CANDIDATE_NOT_FOUND",new Object [] {candidateId}));
		}
		return candidateModel;
	}
	
	
	public CandidateModel updateCandidateDetail(CandidateModel candidateModel) {
		Mapper mapper = new Mapper();
		Optional<CandidateEntity> optionalEntity =  candidateRepository.findById(candidateModel.getCandidateId());
		CandidateEntity candidateEntity = new CandidateEntity();
		candidateEntity = mapper.mapModelToEntity(candidateModel, candidateEntity);
		CandidateEntity candidateEntitySaved =  candidateRepository.save(candidateEntity);
		CandidateModel candidateModelSaved = new CandidateModel();
		candidateModelSaved = mapper.mapEntityToModel(candidateEntitySaved, candidateModelSaved);
		
		if(candidateEntitySaved!=null && optionalEntity.isPresent() && candidateEntitySaved.getStatus()!=null &&
				!candidateEntitySaved.getStatus().equalsIgnoreCase(optionalEntity.get().getStatus())) {
			try {
				LOG.info("SEND EMAIL NOTIFICATION METHO CALL");
				sendStatusChangeNotification(optionalEntity.get(),candidateEntitySaved);
			}catch (MessagingException e) {
				// TODO Auto-generated catch block
				LOG.debug("Error occured in sending email notification for status change");
			}
//			catch(Exception e) {
//				LOG.info("some error orccurre");
//				e.printStackTrace();
//			}
		}
		return candidateModelSaved;
	}
	
	public void sendStatusChangeNotification(CandidateEntity before, CandidateEntity after) throws MessagingException {
		LOG.info("COMING TO SEND EMAIL NOTIFICATION METHO");
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		helper.setTo("saini.nitti@gmail.com");
		helper.setFrom("nitinsaini.test@gmail.com");
		helper.setText("Status changed from "+before.getStatus()+" to "+ after.getStatus());
		helper.setCc("nitinsaini.test@gmail.com");
		helper.setSubject("CDP Portal Candidate - "+after.getCandidateId() +" status change");
		
	   javaMailSender.send(message);
	}
	public List<CandidateBasicModel> getAllCandidates() {
		List<CandidateBasicModel> candidateModelList = new ArrayList<>();
		List<CandidateEntity> candidateEntities = new ArrayList<>();
		Mapper mapper = new Mapper();
		candidateEntities =  candidateRepository.findAll();
		if(!candidateEntities.isEmpty()) {
			for(CandidateEntity candidateEntity: candidateEntities) {
				CandidateBasicModel candidateModel = new CandidateBasicModel();
				candidateModelList.add(mapper.mapEntityToModelBasic(candidateEntity,candidateModel));
			}
		}
		return candidateModelList;
	}
	
	public CandidateModel createCandidateInterview(CandidateInterviewModel candidateInterviewModel ) {
		String transactionUrl = "http://localhost:8302/cis/interview/create-interview";
		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder builder = UriComponentsBuilder
			    .fromUriString(transactionUrl);
		String url = builder.toUriString();
		
		InterviewEntity interviewEntity = new InterviewEntity();
		if(candidateInterviewModel!=null) {
//			LOG.info("start time in candidate applcaition ---"+candidateInterviewModel.getStartTime());
//			LOG.info("end time in candidate applcaition ---"+candidateInterviewModel.getEndTime());
			interviewEntity.setFirstPanelistEmailId(candidateInterviewModel.getFirstPanelistEmailId());
			interviewEntity.setLocation(candidateInterviewModel.getLocation());
			interviewEntity.setMode(candidateInterviewModel.getMode());
			interviewEntity.setScheduledDate(candidateInterviewModel.getScheduledDate());
			interviewEntity.setSecondPanelistEmailId(candidateInterviewModel.getSecondPanelistEmailId());
			interviewEntity.setTime(candidateInterviewModel.getTime());
			interviewEntity.setStartTime(candidateInterviewModel.getStartTime());
			interviewEntity.setEndTime(candidateInterviewModel.getEndTime());
		}
		
		CandidateModel createCandidateOutputResponse = new CandidateModel();
		CandidateModel candidateInterviewDetails = new CandidateModel();
		Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateInterviewModel.getCandidateId());
		if(!candidateEntity.isPresent()) {
			//LOG.debug("Inside no candidate found");
			//createCandidateOutputResponse.setResponseStatus("Invalid Candidate ID. Please enter a valid ID and try again");
			throw new CandidateNotFoundException(messages.get("CANDIDATE_NOT_FOUND",new Object [] {candidateInterviewModel.getCandidateId()}));
			//return createCandidateOutputResponse;
		}else {
			//interviewEntity.setCandidateEmail(candidateEntity.get().getCandidateEmail());
			candidateInterviewDetails.setCandidateContact(candidateEntity.get().getCandidateContact());
			candidateInterviewDetails.setCandidateEmail(candidateEntity.get().getCandidateEmail());
			candidateInterviewDetails.setCandidateName(candidateEntity.get().getCandidateName());
			
			interviewEntity.setCandidateModel(candidateInterviewDetails);
			LOG.info("candidate candidate email present  interviewEntity-----"+interviewEntity.getCandidateModel().getCandidateEmail());
		}
		
		ResponseEntity<InterviewEntity> interviewModel = restTemplate.postForEntity(url, interviewEntity, InterviewEntity.class);
		
		if(interviewModel!=null && interviewModel.getStatusCode()==HttpStatus.OK) {
			InterviewEntity interviewEntityResponse = interviewModel.getBody();
			if(interviewEntityResponse!=null) {
				//Optional<CandidateEntity> candidateEntity = candidateRepository.findById(candidateInterviewModel.getCandidateId());
				if(candidateEntity.isPresent()) {
					CandidateEntity candidateUpdate = candidateEntity.get();
					candidateUpdate.setInterviewId(interviewEntityResponse.getInterviewId());
					CandidateEntity entity = new CandidateEntity();
					entity = candidateRepository.save(candidateUpdate);
					createCandidateOutputResponse.setInterviewId(entity.getInterviewId());
					//LOG.info("indide candidate id present "+entity.getCandidateId());
					LOG.info("indide candidate enail present "+entity.getCandidateEmail());
					createCandidateOutputResponse.setCandidateId(entity.getCandidateId());
					createCandidateOutputResponse.setCandidateEmail(entity.getCandidateEmail());
					return  createCandidateOutputResponse;
				}
			}
		}
		return null;
	}
}
