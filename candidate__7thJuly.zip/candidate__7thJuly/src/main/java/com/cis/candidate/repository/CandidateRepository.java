package com.cis.candidate.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cis.candidate.entity.CandidateEntity;

public interface CandidateRepository extends MongoRepository<CandidateEntity, String>{

}
