package com.cis.candidate.controller;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cis.candidate.exception.model.ValidationError;
import com.cis.candidate.exception.model.ValidationErrorContainer;
import com.cis.candidate.model.CandidateInterviewModel;
import com.cis.candidate.model.CandidateList;
import com.cis.candidate.model.CandidateModel;
import com.cis.candidate.service.CandidateService;
@CrossOrigin(origins = "*")
@RestController
@EnableAutoConfiguration
@ControllerAdvice
@RequestMapping("/cis/candidate")
public class CandidateContoller {

	private static final Logger LOG = LoggerFactory.getLogger(CandidateContoller.class);

	@Autowired
	CandidateService candidateService;
	
	
	
//	@CrossOrigin(origins = "*")
	@RequestMapping(value ="/create-candidate",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> createCandidate( @RequestBody @Valid CandidateModel candidateModel, Errors errors) {
		LOG.info("---------------CREATE CANDIDATE CONTROLLER METHOD START-----------------");
		if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(ValidationErrorContainer.fromBindingErrors(errors));
        }
        return ResponseEntity.ok(candidateService.createCandidate(candidateModel,errors));
		//return candidateService.createCandidate(candidateModel,errors);
	}
	
	@RequestMapping(value ="/{id}",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public  CandidateModel getCandidateDetails(@PathVariable("id") String candidateId) {
		return candidateService.getCandidateDetails(candidateId);
	}
	
	@RequestMapping(value ="/update",method = RequestMethod.PUT, consumes= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateCandidateDetail(@RequestBody @Valid CandidateModel candidateModel,Errors errors) {
		if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(ValidationErrorContainer.fromBindingErrors(errors));
        }
		return ResponseEntity.ok(candidateService.updateCandidateDetail(candidateModel));
	}
	
	@RequestMapping(value ="/all",method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
	public CandidateList getAllCandidates() {
		CandidateList candidateList = new CandidateList();
		candidateList.setListOfCandidates(candidateService.getAllCandidates());
		return candidateList;
	}
	
	@RequestMapping(value ="/create-candidate-interview",method = RequestMethod.POST, consumes= MediaType.APPLICATION_JSON_VALUE)
	public CandidateModel createCandidateInterview(@RequestBody CandidateInterviewModel candidateInterviewModel) {
		return candidateService.createCandidateInterview(candidateInterviewModel);
	}
	
	
	@Bean
	public LocalValidatorFactoryBean validator(MessageSource messageSource) {
	    LocalValidatorFactoryBean validatorFactoryBean = new LocalValidatorFactoryBean();
	    validatorFactoryBean.setValidationMessageSource(messageSource);
	    return validatorFactoryBean;
	}

}
