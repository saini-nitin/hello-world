package com.cis.candidate.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FormValidationException extends RuntimeException{

	private static final Logger LOG = LoggerFactory.getLogger(FormValidationException.class);

	public FormValidationException(String exception) {
		super(exception);
		LOG.info("BUSINESS EXCEPTION --------FORM VALIDATION EXCEPTION");
	}
}
