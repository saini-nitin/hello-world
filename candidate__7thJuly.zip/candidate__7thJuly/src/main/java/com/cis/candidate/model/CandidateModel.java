package com.cis.candidate.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CandidateModel extends CandidateBasicModel{

//    private String candidateId;
//	private String candidateName;
	private String practice;
	private String customerAC;
	private String quarter;
	private String recievedDate;
//	private String notes;
	private String offerPU;
	private String demandId;
	@NotBlank(message="{CANDIDATE.LOCATION.NOT_BLANK}")
	@NotNull(message="{CANDIDATE.LOCATION.NOT_NULL}")
	@Size(min=2,max=100,message="{CANDIDATE.LOCATION.SIZE}")
	private String location;
	private String doj;
	
//	private String candidateContact;
//	private String status;
	private String remark;
	private String background;
	private String weekEndingDate;
	private String recievedMonth;
	private String parentSkillSet;
	private String responsible;
	private String profileAge;
	@Email(message="{PANELIST.EMAIL}")
	private String firstPanelistEmailId;
	@Email(message="{PANELIST.EMAIL}")
	private String secondPanelistEmailId;
	
	private String interviewId;
	
//	private String responseStatus;
//	private String candidateEmail;

	

	

	public String getPractice() {
		return practice;
	}

	public void setPractice(String practice) {
		this.practice = practice;
	}

	public String getCustomerAC() {
		return customerAC;
	}

	public void setCustomerAC(String customerAC) {
		this.customerAC = customerAC;
	}

	public String getQuarter() {
		return quarter;
	}

	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}

	public String getRecievedDate() {
		return recievedDate;
	}

	public void setRecievedDate(String recievedDate) {
		this.recievedDate = recievedDate;
	}

	

	public String getOfferPU() {
		return offerPU;
	}

	public void setOfferPU(String offerPU) {
		this.offerPU = offerPU;
	}

	public String getDemandId() {
		return demandId;
	}

	public void setDemandId(String demandId) {
		this.demandId = demandId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getBackground() {
		return background;
	}

	public void setBackground(String background) {
		this.background = background;
	}

	public String getWeekEndingDate() {
		return weekEndingDate;
	}

	public void setWeekEndingDate(String weekEndingDate) {
		this.weekEndingDate = weekEndingDate;
	}

	public String getRecievedMonth() {
		return recievedMonth;
	}

	public void setRecievedMonth(String recievedMonth) {
		this.recievedMonth = recievedMonth;
	}

	public String getParentSkillSet() {
		return parentSkillSet;
	}

	public void setParentSkillSet(String parentSkillSet) {
		this.parentSkillSet = parentSkillSet;
	}

	public String getResponsible() {
		return responsible;
	}

	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}

	public String getProfileAge() {
		return profileAge;
	}

	public void setProfileAge(String profileAge) {
		this.profileAge = profileAge;
	}

	public String getInterviewId() {
		return interviewId;
	}

	public void setInterviewId(String interviewId) {
		this.interviewId = interviewId;
	}

	public String getFirstPanelistEmailId() {
		return firstPanelistEmailId;
	}

	public void setFirstPanelistEmailId(String firstPanelistEmailId) {
		this.firstPanelistEmailId = firstPanelistEmailId;
	}

	public String getSecondPanelistEmailId() {
		return secondPanelistEmailId;
	}

	public void setSecondPanelistEmailId(String secondPanelistEmailId) {
		this.secondPanelistEmailId = secondPanelistEmailId;
	}
	
}
