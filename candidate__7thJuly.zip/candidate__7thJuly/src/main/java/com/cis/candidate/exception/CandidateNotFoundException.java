package com.cis.candidate.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class CandidateNotFoundException extends RuntimeException {

	private static final Logger LOG = LoggerFactory.getLogger(CandidateNotFoundException.class);

	public CandidateNotFoundException(String exception) {
		super(exception);
		LOG.info("BUSINESS EXCEPTION --------CANDIDATE NOT FOUND");
	}
}
