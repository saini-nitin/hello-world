package com.cis.candidate.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.cis.candidate.exception.CandidateNotFoundException;
import com.cis.candidate.exception.DuplicateKeyCustomException;
import com.cis.candidate.exception.FormValidationException;
import com.cis.candidate.exception.TechincalException;
import com.cis.candidate.exception.model.ErrorDetails;
import com.cis.candidate.exception.model.ValidationError;
import com.cis.candidate.exception.model.ValidationErrorContainer;

@ControllerAdvice
@RestController
public class ExceptionHandlerController extends ResponseEntityExceptionHandler {

	private static final Logger LOG = LoggerFactory.getLogger(CandidateContoller.class);

	@ExceptionHandler(CandidateNotFoundException.class)
	public final ResponseEntity<Object> handleCandidateNotFoundException(CandidateNotFoundException ex,
			WebRequest request) {
		LOG.info("BUSINESS EXCEPTION HANDLER --------- CANDIDATE NOT FOUND");
		ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false),HttpStatus.NOT_FOUND);
		return new ResponseEntity(errorDetails, HttpStatus.NOT_FOUND);
	}
	

	@ExceptionHandler(TechincalException.class)
	public final ResponseEntity<Object> handleTechnicalException(TechincalException ex,
			WebRequest request) {
		LOG.info("BUSINESS EXCEPTION HANDLER ---------TECHINCAL ERROR");
		ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false),HttpStatus.NO_CONTENT);
		return new ResponseEntity(errorDetails, HttpStatus.NO_CONTENT);
	}
	
	@ExceptionHandler(DuplicateKeyCustomException.class)
	public final ResponseEntity<Object> handleDuplicateKeyException(DuplicateKeyCustomException ex,
			WebRequest request) {
		LOG.info("BUSINESS EXCEPTION HANDLER ---------DUPLICATE KEY EXCEPTION");
		ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false),HttpStatus.CONFLICT);
		return new ResponseEntity(errorDetails, HttpStatus.CONFLICT);
	}
	
	
//	@ExceptionHandler(MethodArgumentNotValidException.class)
////	@ExceptionHandler({FormValidationException.class})
//	public ValidationError handleFormValidationsException(MethodArgumentNotValidException ex,
//			WebRequest request) {
//		LOG.info("BUSINESS EXCEPTION HANDLER ---------FORM VALIDATION EXCEPTIONS");
//		//ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false),HttpStatus.CONFLICT);
//		//return new ResponseEntity(ex, HttpStatus.CONFLICT);
//        return createValidationError(ex);
//
//	}
//	
//	private ValidationError createValidationError(MethodArgumentNotValidException e) {
//        return ValidationErrorContainer.fromBindingErrors(e.getBindingResult());
//    }
	
//	// #2: Specify which exception this handler can handle
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//    // #3: Specify the HTTP Status code to return when an error occurs
//    @ResponseStatus(HttpStatus.CONFLICT)
//    // #4: Let Spring know that we have something to return in the body of the
//    // response. In this case it will be a ValidationErrorContainer containing
//    // a ValidationError object for each field that did not pass validation.
//    @ResponseBody
//    public  ValidationErrorContainer processValidationErrors(MethodArgumentNotValidException e) {
//    // #5: get the Binding Result and all field errors
//        BindingResult result = e.getBindingResult();
//        List<FieldError> fieldErrors = result.getFieldErrors();
//
//        // #6: Create a new ValidationError for each fieldError in the Binding Result
//        ValidationErrorContainer errors = new ValidationErrorContainer();
//        for(FieldError currentError : fieldErrors) {
//            errors.addValidationError(currentError.getField(), currentError.getDefaultMessage());
//        }
//        return errors;
//    }
}
