package com.cis.candidate.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CandidateBasicModel {

	private String candidateId;
	@NotBlank(message="{CANDIDATE.NAME.NOT_BLANK}")
	@NotNull(message="{CANDIDATE.NAME.NOT_NULL}")
	@Size(min=2,max=30,message="{CANDIDATE.NAME.SIZE}")
	private String candidateName;
	private String candidateContact;
	private String status;
	private String responseStatus;
	@Email(message="{CANDIDATE.EMAIL}")
	private String candidateEmail;
	private String notes;
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getCandidateContact() {
		return candidateContact;
	}
	public void setCandidateContact(String candidateContact) {
		this.candidateContact = candidateContact;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getCandidateEmail() {
		return candidateEmail;
	}
	public void setCandidateEmail(String candidateEmail) {
		this.candidateEmail = candidateEmail;
	}
	
}
