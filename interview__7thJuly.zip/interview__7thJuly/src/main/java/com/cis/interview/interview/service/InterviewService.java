package com.cis.interview.interview.service;

import java.io.IOException;
import java.util.Date;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;


import com.cis.interview.interview.entity.InterviewEntity;
import com.cis.interview.interview.mapper.Mapper;
import com.cis.interview.interview.model.InterviewModel;
import com.cis.interview.interview.repository.InterviewRepository;

import biweekly.Biweekly;
import biweekly.ICalendar;
import biweekly.component.VAlarm;
import biweekly.component.VEvent;
import biweekly.parameter.ParticipationLevel;
import biweekly.parameter.ParticipationStatus;
import biweekly.parameter.Related;
import biweekly.parameter.Role;
import biweekly.property.Action;
import biweekly.property.Attendee;
import biweekly.property.DateEnd;
import biweekly.property.DateStart;
import biweekly.property.Trigger;
import biweekly.util.Duration;

@Service
public class InterviewService {

	private static final Logger LOG = LoggerFactory.getLogger(InterviewService.class);

	
	@Autowired
	InterviewRepository interviewRepository;
	
	private JavaMailSender javaMailSender;
	
	@Autowired
	public InterviewService(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	public InterviewEntity createCandidateInterview(InterviewModel interviewModel) {
		Mapper mapper = new Mapper();
		InterviewEntity interviewEntity = new InterviewEntity();
		interviewEntity = mapper.modelToEntity(interviewModel, interviewEntity);
		try {
			createMeeting(interviewModel);
		} catch (MailException | MessagingException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return interviewRepository.insert(interviewEntity);
	}
	
	public void createMeeting(InterviewModel interviewModel) throws MailException, MessagingException, IOException{
		
//		SimpleMailMessage mail  = new SimpleMailMessage();
//		mail.setTo("saini.nitti11792@gmail.com");
//		mail.setFrom("nitinsaini.test@gmail.com");
//		mail.setSubject("test create interview");
//		mail.setText("Testing send email spring boot");
	
//		MimeMessage message = javaMailSender.createMimeMessage();
//		MimeMessageHelper helper = new MimeMessageHelper(message);
//		helper.setTo("saini.nitti11792@gmail.com");
//		helper.setFrom("nitinsaini.test@gmail.com");
//		helper.setSubject("Testing");
//		helper.setCc("saini.nitti@gmail.com");
		//JavaMailSenderImpl sender = new JavaMailSenderImpl();
//		MimeMessage message = javaMailSender.createMimeMessage();
//		MimeMessageHelper helper = new MimeMessageHelper(message);
//		helper.setTo("saini.nitti11792@gmail.com");
//		helper.setFrom("nitinsaini.test@gmail.com");
//		helper.setText("Thank yoo!");
//		helper.setCc("saini.nitti@gmail.com");
//		helper.setSubject("TEST!!!!!!!!!!");

//		LOG.debug("coming to this flow email: ",interview.getCandidateEmail());
//		LOG.debug("coming to this flow start time",interview.getStartTime());
//		LOG.debug("coming to this flow end time",interview.getEndTime());
//		
		String startTime = null;
		String endTime = null;
		String[] sTime = null;
		String[] eTime = null;
		String[] scheduledDateArray = null;
		//javaMailSender.send(message);
		//javaMailSender.send(message);
		if(interviewModel!=null) {
			 startTime = interviewModel.getStartTime();
			 endTime = interviewModel.getEndTime();
			 if(interviewModel.getScheduledDate()!=null && interviewModel.getScheduledDate().contains("/")) {
				 scheduledDateArray = interviewModel.getScheduledDate().split("/");
			 }
		}
		
		if(startTime!=null && startTime.contains(":")) {
			 sTime = startTime.split(":"); 	
		}
		if(endTime!=null && endTime.contains(":")) {
			 eTime = endTime.split(":");
		}
		ICalendar ical = new ICalendar();
		ical.setMethod("REQUEST");
	    VEvent event = new VEvent();

	    //Attendee attendee = new Attendee("Nitin", interview.getCandidateEmail());
	    //Attendee attendee = new Attendee("Nitin", "saini.nitti@gmail.com");
	    Attendee attendeeCandidate = new Attendee(interviewModel.getCandidateModel().getCandidateName(), interviewModel.getCandidateModel().getCandidateEmail());

	    attendeeCandidate.setRsvp(true);
	    attendeeCandidate.setRole(Role.ATTENDEE);
	    attendeeCandidate.setParticipationStatus(ParticipationStatus.NEEDS_ACTION);
	    attendeeCandidate.setParticipationLevel(ParticipationLevel.REQUIRED);

	    event.addAttendee(attendeeCandidate);

	    event.setSummary("Testing Sending Meeting");
	   

	    
	    Attendee attendeePanelist = new Attendee(interviewModel.getFirstPanelistEmailId(), interviewModel.getFirstPanelistEmailId());
	    
	    attendeePanelist.setRsvp(true);
	    attendeePanelist.setRole(Role.CHAIR);
	    attendeePanelist.setParticipationStatus(ParticipationStatus.NEEDS_ACTION);
	    attendeePanelist.setParticipationLevel(ParticipationLevel.REQUIRED);
	    
	    
	    event.addAttendee(attendeePanelist);
	    
	    
	    Attendee attendeeOrganizer = new Attendee("nitinsaini.test@gmail.com","nitinsaini.test@gmail.com");
	    
	    attendeeOrganizer.setRsvp(true);
	    attendeeOrganizer.setRole(Role.ORGANIZER);
	    attendeeOrganizer.setParticipationStatus(ParticipationStatus.NEEDS_ACTION);
	    attendeeOrganizer.setParticipationLevel(ParticipationLevel.OPTIONAL);
	    
	    
	    event.addAttendee(attendeeOrganizer);

	    
//	    DateTime dt = new DateTime(2018, 06, 23, 23, 0);
//	    DateTime et = new DateTime(2018, 06, 23, 23, 45);
	    DateTime dt = new DateTime(Integer.parseInt(scheduledDateArray[2]), Integer.parseInt(scheduledDateArray[1])+1, Integer.parseInt(scheduledDateArray[0]), Integer.parseInt(sTime[0]), Integer.parseInt(sTime[1]));
	    DateTime et = new DateTime(Integer.parseInt(scheduledDateArray[2]), Integer.parseInt(scheduledDateArray[1])+1, Integer.parseInt(scheduledDateArray[0]), Integer.parseInt(eTime[0]), Integer.parseInt(eTime[1]));
	    Date starts = (Date) dt.toDate();
	    Date ends = (Date) et.toDate();

	    DateStart thisStart = new DateStart(starts, true);
	    DateEnd dateEnd = new DateEnd(ends, true);

	    event.setDateStart(thisStart);
	    event.setDateEnd(dateEnd);

	    Duration reminder = new Duration.Builder().minutes(15).build();
	    Trigger trigger = new Trigger(reminder, Related.START);
	    Action action = new Action("DISPLAY");
	    VAlarm valarm = new VAlarm(action, trigger);
	    event.addAlarm(valarm);

	    Duration duration = new Duration.Builder().hours(1).build();
	    event.setDuration(duration);

	    event.setUid("555xxx");
	    event.setOrganizer("nitinsaini.test@gmail.com");
	    event.setLocation("Pune");

	    ical.addEvent(event);

	    String str = Biweekly.write(ical).go();

	    MimeMessage message = javaMailSender.createMimeMessage();
	    message.addHeaderLine("charset=UTF-8");
	    message.addHeaderLine("component=VEVENT");
	    message.addHeaderLine("method=REQUEST");

	    message.setFrom("nitinsaini.test@gmail.com");
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress(interviewModel.getCandidateModel().getCandidateEmail()));
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress("nitinsaini.test@gmail.com"));
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress(interviewModel.getFirstPanelistEmailId()));
	    message.addRecipient(Message.RecipientType.TO, new InternetAddress(interviewModel.getSecondPanelistEmailId()));
	    message.setSubject("You're Invited to a Meeting");

	    // Create the message part
	    BodyPart messageBodyPart = new MimeBodyPart();

	    // Fill the message
	    messageBodyPart.setHeader("Content-Class", "urn:content-classes:calendarmessage");
	    messageBodyPart.setHeader("Content-ID", "calendar_message");
	    messageBodyPart.setDataHandler(new DataHandler(new ByteArrayDataSource(str, "text/calendar")));// very important
	    //messageBodyPart.setText("This is message body");


	    Multipart multipart = new MimeMultipart();


	    multipart.addBodyPart(messageBodyPart);


	    message.setContent(multipart);

	    javaMailSender.send(message);
		
		
	}
	
	
}
