package com.cis.interview.interview.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cis.interview.interview.entity.InterviewEntity;

public interface InterviewRepository extends MongoRepository<InterviewEntity, Long>{

}
