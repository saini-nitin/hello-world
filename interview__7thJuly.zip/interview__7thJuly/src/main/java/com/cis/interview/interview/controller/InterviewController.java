package com.cis.interview.interview.controller;

import java.io.IOException;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cis.interview.interview.entity.InterviewEntity;
import com.cis.interview.interview.model.InterviewModel;
import com.cis.interview.interview.service.InterviewService;

@RestController
@RequestMapping("/cis/interview")
public class InterviewController {

	@Autowired
	InterviewService interviewService;
	
	@RequestMapping(value ="/create-interview",method = RequestMethod.POST, headers = "Accept=application/json",consumes= MediaType.APPLICATION_JSON_VALUE)
	public InterviewEntity createCandidate(@RequestBody InterviewModel interviewModel) {
		return interviewService.createCandidateInterview(interviewModel);
	}
	
	@RequestMapping(value ="/email")
	public String sendEmail() throws IOException {
		try {
			//interviewService.sendNotification();
			return "testing email service success";
		}catch (MailException e) {
			// TODO: handle exception
			e.printStackTrace();
		
		}
//		catch (MessagingException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
		return "testing email  error response";
	}
}
