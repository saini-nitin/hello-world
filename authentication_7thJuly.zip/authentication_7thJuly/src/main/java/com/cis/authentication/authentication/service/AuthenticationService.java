package com.cis.authentication.authentication.service;

import org.springframework.stereotype.Service;

import com.cis.authentication.authentication.model.UserModel;

@Service
public class AuthenticationService {

	
	public UserModel authenticateUser(UserModel user) {
		UserModel authUser = new UserModel();
		authUser.setLoginStatus(false);
		if(user!=null && user.getUserName()!=null && user.getPassword()!=null) {
			authUser.setUserName(user.getUserName());
			if(user.getUserName().equals("admin") && user.getPassword().equals("password")) {
				authUser.setLoginStatus(true);
			}
		}
		return authUser;
	}
}
